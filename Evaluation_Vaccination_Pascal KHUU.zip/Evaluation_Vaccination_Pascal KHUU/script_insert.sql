


-- spécialité categorie_vaccination
insert into specialite (id_specialite,libelle) values (1,'ORL');
insert into specialite  (id_specialite,libelle) values(2,'dentiste');
insert into specialite  (id_specialite,libelle) values(3,'optalmologiste');



-- centre médical
insert into centre_medical (id_centre_medical, nom_departement, numero_rue, nom_rue, code_postal, ville) values (1,'Haut-De-Seine',5,'rue de Loire',92000,'Bagneux');
insert into centre_medical (id_centre_medical, nom_departement, numero_rue, nom_rue, code_postal, ville) values (2, 'Val-de-Marne',6,'rue de Paris',94000,'Saint Maur');
insert into centre_medical (id_centre_medical, nom_departement, numero_rue, nom_rue, code_postal, ville) values (3, 'Paris',58,'avenue de Paris',75000,'Paris');

-- médecin
insert into medecin (id_medecin, nom_medecin, prenom_medecin, id_centre_medical) values (12345, 'LeGrand', 'Christophe',1);
insert into medecin (id_medecin, nom_medecin, prenom_medecin, id_centre_medical) values (23456, 'Lee', 'Pierre',1);
insert into medecin (id_medecin, nom_medecin, prenom_medecin, id_centre_medical) values (34567, 'Tou', 'Mathilde',2);

-- avoir
insert into avoir (id_medecin,id_specialite) values (12345,1);
insert into avoir (id_medecin,id_specialite) values (12345,2);
insert into avoir (id_medecin,id_specialite) values (23456,3);
insert into avoir (id_medecin,id_specialite) values (34567,1);
insert into avoir (id_medecin,id_specialite) values (34567,2);
insert into avoir (id_medecin,id_specialite) values (34567,3);

-- ecole
insert into ecole (id_ecole, nom_ecole, numero_rue, nom_rue, code_postal, ville) values (1, 'Jacques', 25, 'rue de la Loire',75000,'Paris');
insert into ecole (id_ecole, nom_ecole, numero_rue, nom_rue, code_postal, ville)  values (2, 'Mitterrand', 50, 'rue de Paris',75000,'Paris');
insert into ecole (id_ecole, nom_ecole, numero_rue, nom_rue, code_postal, ville)  values (3, 'Pierrot', 70, 'avenue de Stalingrad',92220,'Bagneux');

-- enfant
insert into enfant (nom_enfant, prenom_enfant, age, sexe, poids, taille, id_ecole) values ('Lee', 'Mathieu',20, 'masculin', 78.8,1.8,1);
insert into enfant (nom_enfant, prenom_enfant, age, sexe, poids, taille, id_ecole)values ('Lee', 'Mathilde',18, 'masculin', 78.8,1.8,2);
insert into enfant (nom_enfant, prenom_enfant, age, sexe, poids, taille, id_ecole) values ('Pomme', 'Paul',20, 'masculin', 80.8,1.82,3);

-- categorie vaccination
insert into categorie_vaccination (code_categorie, nom_categorie_vaccination) values (1, 'grippe');
insert into categorie_vaccination (code_categorie, nom_categorie_vaccination) values (2, 'covid');
insert into categorie_vaccination (code_categorie, nom_categorie_vaccination) values (3, 'rougeole');

-- vaccination
insert into vaccination (id_vaccin, nom_vaccin, date, id_medecin, id_enfant,code_categorie) values (1, 'Moderna', '2021-06-01', 23456,2,2);
insert into vaccination (id_vaccin, nom_vaccin, date, id_medecin, id_enfant,code_categorie) values (2, 'Pfizer', '2021-06-01', 12345,1,2);
insert into vaccination (id_vaccin, nom_vaccin, date, id_medecin, id_enfant,code_categorie) values (3, 'Johnson', '2021-06-01', 34567,3,2);
insert into vaccination (id_vaccin, nom_vaccin, date, id_medecin, id_enfant,code_categorie) values (4, 'Pfizer', '2021-06-01', 23456,1,2);


