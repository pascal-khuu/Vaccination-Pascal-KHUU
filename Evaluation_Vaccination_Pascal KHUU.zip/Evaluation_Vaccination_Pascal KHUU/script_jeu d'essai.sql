-- jeu d'essai
-- spécialité 
select id_specialite, libelle from specialite where id_specialite=1;
select id_specialite, libelle from specialite where id_specialite=2;
select id_specialite, libelle from specialite where id_specialite=3;

-- centre_medical
select id_centre_medical, nom_departement, numero_rue, nom_rue, code_postal, ville from centre_medical where id_centre_medical=1;
select id_centre_medical, nom_departement, numero_rue, nom_rue, code_postal, ville from centre_medical where id_centre_medical=2;
select id_centre_medical, nom_departement, numero_rue, nom_rue, code_postal, ville from centre_medical where id_centre_medical=3;

-- medecin
select id_medecin, nom_medecin, prenom_medecin from medecin where nom_medecin='LeGrand';
select id_medecin, nom_medecin, prenom_medecin from medecin ,centre_medical where centre_medical.id_centre_medical=1 and medecin.id_centre_medical=centre_medical.id_centre_medical;

-- ecole
select id_ecole, nom_ecole, numero_rue, nom_rue, code_postal, ville from ecole where id_ecole=1;
select id_ecole, nom_ecole, numero_rue, nom_rue, code_postal, ville from ecole where id_ecole=2;
select id_ecole, nom_ecole, numero_rue, nom_rue, code_postal, ville from ecole where id_ecole=3;

-- enfant
select id_enfant, nom_enfant, prenom_enfant, age, sexe from enfant where nom_enfant='Lee';
select id_enfant, nom_enfant,nom_ecole prenom, age, sexe from enfant, ecole where ecole.id_ecole=1 and enfant.id_ecole=ecole.id_ecole;
select id_enfant, nom_enfant,nom_ecole  prenom, age, sexe from enfant, ecole where ecole.id_ecole=2 and enfant.id_ecole=ecole.id_ecole;
select id_enfant, nom_enfant,nom_ecole  prenom, age, sexe from enfant, ecole where ecole.id_ecole=3 and enfant.id_ecole=ecole.id_ecole;

-- categorie_vaccination
select code_categorie, nom_categorie_vaccination  from  categorie_vaccination where code_categorie=1;
select code_categorie, nom_categorie_vaccination  from categorie_vaccination where code_categorie=2;
select code_categorie, nom_categorie_vaccination  from categorie_vaccination where code_categorie=3;


-- vaccination
select id_vaccin, nom_vaccin, nom_categorie_vaccination from enfant, categorie_vaccination, medecin, vaccination where nom_vaccin='Pfizer' and categorie_vaccination.code_categorie =2 and vaccination.id_medecin= medecin.id_medecin and vaccination.id_enfant= enfant.id_enfant and vaccination.code_categorie=categorie_vaccination.code_categorie;
select id_vaccin, nom_vaccin, nom_categorie_vaccination from enfant, categorie_vaccination, medecin, vaccination where nom_vaccin='Moderna' and categorie_vaccination.code_categorie =2 and vaccination.id_medecin= medecin.id_medecin and vaccination.id_enfant= enfant.id_enfant and vaccination.code_categorie=categorie_vaccination.code_categorie;