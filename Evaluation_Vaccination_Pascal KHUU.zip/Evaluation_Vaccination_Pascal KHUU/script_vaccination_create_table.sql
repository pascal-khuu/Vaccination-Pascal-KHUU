#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------


#------------------------------------------------------------
# Table: specialite
#------------------------------------------------------------

CREATE TABLE specialite(
        id_specialite Int NOT NULL ,
        libelle       Varchar (50) NOT NULL
	,CONSTRAINT specialite_PK PRIMARY KEY (id_specialite)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: ecole
#------------------------------------------------------------

CREATE TABLE ecole(
        id_ecole    Int NOT NULL ,
        nom_ecole   Varchar (50) NOT NULL ,
        numero_rue  Int NOT NULL ,
        nom_rue     Varchar (50) NOT NULL ,
        code_postal Int NOT NULL ,
        ville       Varchar (50) NOT NULL
	,CONSTRAINT ecole_PK PRIMARY KEY (id_ecole)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: enfant
#------------------------------------------------------------

CREATE TABLE enfant(
        id_enfant     Int  Auto_increment  NOT NULL ,
        nom_enfant    Varchar (50) NOT NULL ,
        prenom_enfant Varchar (50) NOT NULL ,
        age           Int NOT NULL ,
        sexe          Varchar (50) NOT NULL ,
        poids         Float NOT NULL ,
        taille        Float NOT NULL ,
        id_ecole      Int NOT NULL
	,CONSTRAINT enfant_PK PRIMARY KEY (id_enfant)

	,CONSTRAINT enfant_ecole_FK FOREIGN KEY (id_ecole) REFERENCES ecole(id_ecole)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: categorie_vaccination
#------------------------------------------------------------

CREATE TABLE categorie_vaccination(
        code_categorie            Int NOT NULL ,
        nom_categorie_vaccination Varchar (50) NOT NULL
	,CONSTRAINT categorie_vaccination_PK PRIMARY KEY (code_categorie)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: centre_medical
#------------------------------------------------------------

CREATE TABLE centre_medical(
        id_centre_medical Int NOT NULL ,
        nom_departement   Varchar (50) NOT NULL ,
        numero_rue        Int NOT NULL ,
        nom_rue           Varchar (50) NOT NULL ,
        code_postal       Int NOT NULL ,
        ville             Varchar (50) NOT NULL
	,CONSTRAINT centre_medical_PK PRIMARY KEY (id_centre_medical)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: medecin
#------------------------------------------------------------

CREATE TABLE medecin(
        id_medecin        Int NOT NULL ,
        nom_medecin       Varchar (50) NOT NULL ,
        prenom_medecin    Varchar (50) NOT NULL ,
        id_centre_medical Int NOT NULL
	,CONSTRAINT medecin_PK PRIMARY KEY (id_medecin)

	,CONSTRAINT medecin_centre_medical_FK FOREIGN KEY (id_centre_medical) REFERENCES centre_medical(id_centre_medical)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: vaccination
#------------------------------------------------------------

CREATE TABLE vaccination(
        id_vaccin      Int NOT NULL ,
        nom_vaccin     Varchar (50) NOT NULL ,
        date           Date NOT NULL ,
        id_medecin     Int NOT NULL ,
        id_enfant      Int NOT NULL ,
        code_categorie Int NOT NULL
	,CONSTRAINT vaccination_PK PRIMARY KEY (id_vaccin)

	,CONSTRAINT vaccination_medecin_FK FOREIGN KEY (id_medecin) REFERENCES medecin(id_medecin)
	,CONSTRAINT vaccination_enfant0_FK FOREIGN KEY (id_enfant) REFERENCES enfant(id_enfant)
	,CONSTRAINT vaccination_categorie_vaccination1_FK FOREIGN KEY (code_categorie) REFERENCES categorie_vaccination(code_categorie)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: avoir
#------------------------------------------------------------

CREATE TABLE avoir(
        id_medecin    Int NOT NULL ,
        id_specialite Int NOT NULL
	,CONSTRAINT avoir_PK PRIMARY KEY (id_medecin,id_specialite)

	,CONSTRAINT avoir_medecin_FK FOREIGN KEY (id_medecin) REFERENCES medecin(id_medecin)
	,CONSTRAINT avoir_specialite0_FK FOREIGN KEY (id_specialite) REFERENCES specialite(id_specialite)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: affecter
#------------------------------------------------------------

CREATE TABLE affecter(
        id_medecin Int NOT NULL ,
        id_ecole   Int NOT NULL
	,CONSTRAINT affecter_PK PRIMARY KEY (id_medecin,id_ecole)

	,CONSTRAINT affecter_medecin_FK FOREIGN KEY (id_medecin) REFERENCES medecin(id_medecin)
	,CONSTRAINT affecter_ecole0_FK FOREIGN KEY (id_ecole) REFERENCES ecole(id_ecole)
)ENGINE=InnoDB;

